# projekt-ifj-interpret-2022
Interpretu pro fiktivní jazyk ifj2022. 
Projekt do školy FIT VUT.
