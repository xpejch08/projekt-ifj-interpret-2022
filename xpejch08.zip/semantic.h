#ifndef STACK_H
#define STACK_H

#include "lexical.h"
#include "parser.h"
#include "code_gen.h"
#include "symtable.h"
#include "errors.h"


#endif